exports.handler = function (request, context) {
    if (request.directive.header.namespace === 'Alexa.Discovery' && request.directive.header.name === 'Discover') {
        log("DEBUG:", "Discover request",  JSON.stringify(request));
        handleDiscovery(request, context, "");
    }
    else if (request.directive.header.namespace === 'Alexa.PowerController') {
        if (request.directive.header.name === 'TurnOn' || request.directive.header.name === 'TurnOff') {
            log("DEBUG:", "TurnOn or TurnOff Request", JSON.stringify(request));
            handlePowerControl(request, context);
        }
    }

    function handleDiscovery(request, context) {
        let payload = {
            "endpoints":
            [
                {
                    "endpointId": "demo_id",
                    "manufacturerName": "Smart Device Company",
                    "friendlyName": "Bedroom Outlet",
                    "description": "Smart Device Switch",
                    "displayCategories": ["SWITCH"],
                    "capabilities":
                    [
                        {
                          "type": "AlexaInterface",
                          "interface": "Alexa",
                          "version": "3"
                        },
                        {
                            "interface": "Alexa.PowerController",
                            "version": "3",
                            "type": "AlexaInterface",
                            "properties": {
                                "supported": [{
                                    "name": "powerState"
                                }],
                                 "retrievable": true
                            }
                        }
                    ]
                }
            ]
        };

    // Handle directive for Power Control (on or off)
    function handlePowerControl(request, context) {
        // get device ID passed in during discovery
        let requestMethod = request.directive.header.name;
        // get user token pass in request
        let requestToken = request.directive.payload.scope.token;
        let powerResult;

        if (requestMethod === "TurnOn") {
            // Make the call to your device cloud for control 
            // powerResult = stubControlFunctionToYourCloud(endpointId, token, request);
            powerResult = "ON";
        }
        else if (requestMethod === "TurnOff") {
            // Make the call to your device cloud for control and check for success 
            // powerResult = stubControlFunctionToYourCloud(endpointId, token, request);
            powerResult = "OFF";
        }

        let timeOfSample = new Date();
        let contextResult = {
            "properties": [{
                "namespace": "Alexa.PowerController",
                "name": "powerState",
                "value": powerResult,
                "timeOfSample": timeOfSample, 
                "uncertaintyInMilliseconds": 200
            }]
        };
        let responseHeader = request.directive.header;
        responseHeader.name = "Alexa.Response";
        responseHeader.messageId = responseHeader.messageId + "-R";
        let response = {
            context: contextResult,
            event: {
                header: responseHeader
            },
            payload: {}

        };
        log("DEBUG", "Alexa.PowerController ", JSON.stringify(response));
        context.succeed(response);
    }

    // Handle directive for adjusting light brightness
    function handleAdjustBrightness(request, context) {
        // get device ID passed in during discovery
        let requestMethod = request.directive.header.name;
        // get user token pass in request
        let requestToken = request.directive.payload.scope.token;

        // brightnessDelta is a value from -100 to 100
        let brightnessDelta = request.directive.payload.brightnessDelta;
        let timeOfSample = new Date();
        let contextResult = {
            "properties": [{
                "namespace": "Alexa.BrightnessController",
                "name": "brightness",
                "value": brightnessDelta,
                "timeOfSample": timeOfSample, //retrieve from result.
                "uncertaintyInMilliseconds": 200
            }]
        };
        let responseHeader = request.directive.header;
        responseHeader.name = "Alexa.Response";
        responseHeader.messageId = responseHeader.messageId + "-R";
        let response = {
            context: contextResult,
            event: {
                header: responseHeader
            },
            payload: {}

        };
        log("DEBUG", "Alexa.BrightnessController ", JSON.stringify(response));
        context.succeed(response);
    }

    // Handle directiver for setting the brightness of a light
    function handleSetBrightness(request, context) {
        // get device ID passed in during discovery
        let requestMethod = request.directive.header.name;
        // get user token pass in request
        let requestToken = request.directive.payload.scope.token;

        let brightness = request.directive.payload.brightness;
        let timeOfSample = new Date();
        let contextResult = {
            "properties": [{
                "namespace": "Alexa.BrightnessController",
                "name": "brightness",
                "value": brightness,
                "timeOfSample": timeOfSample, //retrieve from result.
                "uncertaintyInMilliseconds": 200
            }]
        };
        let responseHeader = request.directive.header;
        responseHeader.name = "Alexa.Response";
        responseHeader.messageId = responseHeader.messageId + "-R";
        let response = {
            context: contextResult,
            event: {
                header: responseHeader
            },
            payload: {}

        };
        log("DEBUG", "Alexa.BrightnessController ", JSON.stringify(response));
        context.succeed(response);
    }

    // Handle directive for setting the color of a light
    function handleSetColor(request, context) {
        // get device ID passed in during discovery
        let requestMethod = request.directive.header.name;
        // get user token pass in request
        let requestToken = request.directive.payload.scope.token;

        let color = request.directive.payload.color;

        let timeOfSample = new Date();
        let contextResult = {
            "properties": [{
                "namespace": "Alexa.ColorController",
                "name": "color",
                "value": color,
                "timeOfSample": timeOfSample, //retrieve from result.
                "uncertaintyInMilliseconds": 200
            }]
        };
        let responseHeader = request.directive.header;
        responseHeader.name = "Alexa.Response";
        responseHeader.messageId = responseHeader.messageId + "-R";
        let response = {
            context: contextResult,
            event: {
                header: responseHeader
            },
            payload: {}

        };
        log("DEBUG", "Alexa.ColorController ", JSON.stringify(response));
        context.succeed(response);
    };
        let header = request.directive.header;
        header.name = "Discover.Response";
        log("DEBUG", "Discovery Response: ", JSON.stringify({ header: header, payload: payload }));
        context.succeed({ event: { header: header, payload: payload } });
    }

    function log(message, message1, message2) {
        console.log(message + message1 + message2);
    }
};
